#ifndef GETCLOCK_H
#define GETCLOCK_H

int GetYear();

int GetMonth();

int GetDay();

int GetHour();

int GetMinute();

int GetSecond();

#endif
