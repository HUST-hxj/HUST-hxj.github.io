#ifndef DISCARD_H
#define DISCARD_H

#include<vector>
#include<string>

using namespace std;

extern vector<string> GetFileList(string,string,int);

extern const char *LastFile(string,string);

#endif
