package main

import (
	"crypto/aes"
	"fmt"
	"net"
	"strconv"
)

func Encrypt(data, key []byte) []byte {
	block, _ := aes.NewCipher(key)
	var cipher_data = make([]byte, len(data))
	block.Encrypt(cipher_data, data)
	return cipher_data
}

func Decrypt(cipher_data, key []byte) []byte {
	block, _ := aes.NewCipher(key)
	var data = make([]byte, len(cipher_data))
	block.Decrypt(data, cipher_data)
	return data
}

func EncryptBlock(data, key []byte) ([]byte, int) {
	var cipher_data []byte
	len_bak := len(data)
	for len(data) >= 127 {
		data = append([]byte{127}, data...)
		for i := 0; i < 8; i++ {
			cipher_data = append(cipher_data, Encrypt(data[:16], key)...)
			data = data[16:]
		}
	}
	if len(data) > 0 {
		padding := 127 - len(data)
		data = append([]byte{byte(len(data))}, data...)
		data = append(data, make([]byte, padding)...)
		for i := 0; i < 8; i++ {
			cipher_data = append(cipher_data, Encrypt(data[:16], key)...)
			data = data[16:]
		}
	}
	return cipher_data, len_bak
}

func DecryptBlock(cipher_data, key []byte) ([]byte, int) {
	var data []byte
	len_bak := len(cipher_data)
	for len(cipher_data) >= 128 {
		var temp []byte
		for i := 0; i < 8; i++ {
			temp = append(temp, Decrypt(cipher_data[:16], key)...)
			cipher_data = cipher_data[16:]
		}
		data = append(data, temp[1:temp[0]+1]...)
	}
	return data, len_bak
}

func ReadLocal(conn0 net.Conn, cipher_data *[]byte, ch0 chan int) {
	for {
		temp := make([]byte, 51200)
		n, err := conn0.Read(temp)
		*cipher_data = append(*cipher_data, temp[:n]...)
		ch0 <- n
		if n == 0 {
			return
		}
		if err != nil {
			fmt.Printf("Read local:")
			fmt.Println(err)
			n = 0
			ch0 <- n
			return
		}
	}
}

func ReadTarget(conn1 net.Conn, data *[]byte, ch1 chan int) {
	for {
		temp := make([]byte, 51200)
		n, err := conn1.Read(temp)
		*data = append(*data, temp[:n]...)
		ch1 <- n
		if n == 0 {
			return
		}
		if err != nil {
			fmt.Printf("Read target:")
			fmt.Println(err)
			n = 0
			ch1 <- n
			return
		}
	}
}

func ShutConn(conn net.Conn) {
	err := conn.Close()
	if err != nil {
		fmt.Printf("Shut conn:")
		fmt.Println(err)
	}
}

func Forward(conn0 net.Conn) {
	var data, cipher_data, key []byte
	//Get key
	for {
		temp := make([]byte, 500)
		n, err := conn0.Read(temp)
		if err != nil {
			fmt.Printf("Get key:")
			fmt.Println(err)
			ShutConn(conn0)
			return
		}
		cipher_data = append(cipher_data, temp[:n]...)
		if len(cipher_data) >= 32 {
			key = cipher_data[:32]
			cipher_data = cipher_data[32:]
			break
		}
	}
	//Get request
	for {
		temp := make([]byte, 500)
		n, err := conn0.Read(temp)
		cipher_data = append(cipher_data, temp[:n]...)
		for len(cipher_data) >= 16 {
			data = append(data, Decrypt(cipher_data[:16], key)...)
			cipher_data = cipher_data[16:]
		}
		if len(data) > 1 && len(data) >= int(data[0])+3 {
			break
		}
		if err != nil {
			fmt.Printf("Get request:")
			fmt.Println(err)
			ShutConn(conn0)
			return
		}
	}
	if len(data) == 0 {
		ShutConn(conn0)
		return
	}
	flag := 0
	for data[len(data)-1] == 0 {
		data = data[:len(data)-1]
	}
	port := int(data[len(data)-2])*256 + int(data[len(data)-1])
	conn1, err := net.Dial("tcp", string(data[1:data[0]+1])+":"+strconv.Itoa(port))
	if err == nil {
		fmt.Printf("Successed: %s\n", string(data[1:data[0]+1])+":"+strconv.Itoa(port))
		conn0.Write([]byte{0})
		flag = 0
	} else {
		fmt.Printf("Failed: %s\n", string(data[1:data[0]+1])+":"+strconv.Itoa(port))
		conn0.Write([]byte{4})
		flag = 1
	}
	data = data[len(data):]
	if flag == 1 {
		ShutConn(conn0)
		return
	}
	//Get data
	data = data[len(data):]
	cipher_data = cipher_data[len(cipher_data):]
	ch0 := make(chan int)
	ch1 := make(chan int)
	flag0 := 0
	flag1 := 0
	go ReadLocal(conn0, &cipher_data, ch0)
	go ReadTarget(conn1, &data, ch1)
	for {
		select {
		case n := <-ch0:
			if len(cipher_data)%128 == 0 {
				buf0, n0 := DecryptBlock(cipher_data, key)
				cipher_data = cipher_data[n0:]
				for len(buf0) > 0 {
					n, err := conn1.Write(buf0)
					if err != nil {
						fmt.Printf("Write target:")
						fmt.Println(err)
						ShutConn(conn0)
						return
					}
					buf0 = buf0[n:]
				}
			}
			if n == 0 {
				flag0 = 1
				if flag1 == 1 {
					ShutConn(conn1)
					ShutConn(conn0)
					return
				}
			}
		case n := <-ch1:
			buf1, n1 := EncryptBlock(data, key)
			data = data[n1:]
			for len(buf1) > 0 {
				n, err := conn0.Write(buf1)
				if err != nil {
					fmt.Printf("Write local:")
					fmt.Println(err)
					ShutConn(conn1)
					return
				}
				buf1 = buf1[n:]
			}
			if n == 0 {
				flag1 = 1
				if flag0 == 1 {
					ShutConn(conn1)
					ShutConn(conn0)
					return
				}
			}
		}
	}
}

func main() {
	listener, err := net.Listen("tcp", "0.0.0.0:10086")
	if err != nil {
		fmt.Printf("Listen:")
		fmt.Println(err)
		return
	}
	for {
		conn0, err0 := listener.Accept()
		if err0 == nil {
			go Forward(conn0)
		} else {
			fmt.Printf("Accept:")
			fmt.Println(err0)
		}
	}
}
