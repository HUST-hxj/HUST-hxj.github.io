package main

import (
	"crypto/aes"
	"fmt"
	"math/rand"
	"net"
	"os"
	"strconv"
	"time"
)

func init() {
	rand.Seed(time.Now().Unix())
}

func GenerateKey() []byte {
	var key []byte
	for i := 0; i < 32; i++ {
		key = append(key, byte(rand.Int()))
	}
	return key
}

func Encrypt(data []byte, key []byte) []byte {
	block, _ := aes.NewCipher(key)
	var cipher_data = make([]byte, len(data))
	block.Encrypt(cipher_data, data)
	return cipher_data
}

func Decrypt(cipher_data, key []byte) []byte {
	block, _ := aes.NewCipher(key)
	var data = make([]byte, len(cipher_data))
	block.Decrypt(data, cipher_data)
	return data
}

func EncryptBlock(data, key []byte) ([]byte, int) {
	var cipher_data []byte
	len_bak := len(data)
	for len(data) >= 127 {
		data = append([]byte{127}, data...)
		for i := 0; i < 8; i++ {
			cipher_data = append(cipher_data, Encrypt(data[:16], key)...)
			data = data[16:]
		}
	}
	if len(data) > 0 {
		padding := 127 - len(data)
		data = append([]byte{byte(len(data))}, data...)
		data = append(data, make([]byte, padding)...)
		for i := 0; i < 8; i++ {
			cipher_data = append(cipher_data, Encrypt(data[:16], key)...)
			data = data[16:]
		}
	}
	return cipher_data, len_bak
}

func DecryptBlock(cipher_data, key []byte) ([]byte, int) {
	var data []byte
	len_bak := len(cipher_data)
	for len(cipher_data) >= 128 {
		var temp []byte
		for i := 0; i < 8; i++ {
			temp = append(temp, Decrypt(cipher_data[:16], key)...)
			cipher_data = cipher_data[16:]
		}
		data = append(data, temp[1:temp[0]+1]...)
	}
	return data, len_bak
}

func ReadClient(conn0 net.Conn, data *[]byte, ch0 chan int) {
	for {
		temp := make([]byte, 51200)
		n, err := conn0.Read(temp)
		*data = append(*data, temp[:n]...)
		ch0 <- n
		if n == 0 {
			return
		}
		if err != nil {
			fmt.Printf("Read client:")
			fmt.Println(err)
			n = 0
			ch0 <- n
			return
		}
	}
}

func ReadRemote(conn1 net.Conn, cipher_data *[]byte, ch1 chan int) {
	for {
		temp := make([]byte, 51200)
		n, err := conn1.Read(temp)
		*cipher_data = append(*cipher_data, temp[:n]...)
		ch1 <- n
		if n == 0 {
			return
		}
		if err != nil {
			fmt.Printf("Read remote:")
			fmt.Println(err)
			n = 0
			ch1 <- n
			return
		}
	}
}

func CreateLog() {
	_, err := os.Stat("log.txt")
	if err != nil {
		file, err := os.Create("log.txt")
		if err != nil {
			fmt.Println(err)
		} else {
			file.Close()
		}
	}
}

func WriteLog(conn net.Conn, request []byte) {
	port := int(request[len(request)-2])*256 + int(request[len(request)-1])
	target := string(request[1:request[0]+1]) + ":" + strconv.Itoa(port)
	file, err := os.OpenFile("log.txt", os.O_APPEND|os.O_WRONLY, os.ModeAppend)
	if err != nil {
		fmt.Println(err)
		return
	} else {
		timer := time.Now()
		_, err := file.WriteString(timer.String() + " : " + conn.LocalAddr().String() + " -> " + target + "\n")
		if err != nil {
			fmt.Println(err)
		}
		file.Close()
	}
}

func ShutConn(conn net.Conn) {
	err := conn.Close()
	if err != nil {
		fmt.Printf("Shut conn:")
		fmt.Println(err)
	}
}

func Forward(conn0 net.Conn) {
	for {
		//conn1, err1 := net.Dial("tcp", "127.0.0.1:10086")
		conn1, err1 := net.Dial("tcp", "139.180.136.153:10086")
		if err1 != nil {
			fmt.Println(err1)
			ShutConn(conn0)
			return
		}
		var data, cipher_data, key []byte
		//Send key
		key = GenerateKey()
		_, err := conn1.Write(key)
		if err != nil {
			fmt.Printf("Send key:")
			fmt.Println(err)
			ShutConn(conn0)
			return
		}
		//Reply header
		for {
			temp := make([]byte, 50)
			n, err := conn0.Read(temp)
			if err != nil {
				fmt.Printf("Reply header:")
				fmt.Println(err)
				ShutConn(conn0)
				return
			}
			data = append(data, temp[:n]...)
			if len(data) >= 3 {
				conn0.Write([]byte{5, 0})
				data = data[3:]
				break
			}
		}
		//Send request
		for {
			temp := make([]byte, 500)
			n, err := conn0.Read(temp)
			data = append(data, temp[:n]...)
			if len(data) >= 5 && len(data) == int(data[4])+7 {
				break
			}
			if err != nil {
				fmt.Printf("Send request:")
				fmt.Println(err)
				ShutConn(conn0)
				return
			}
		}
		request := data[4:]
		request_reserve := request
		for len(request) >= 16 {
			cipher_data = append(cipher_data, Encrypt(request[:16], key)...)
			request = request[16:]
		}
		if len(request) > 0 {
			request = append(request, make([]byte, 16-len(request))...)
			cipher_data = append(cipher_data, Encrypt(request[:16], key)...)
			request = request[16:]
		}
		for len(cipher_data) > 0 {
			n, err := conn1.Write(cipher_data)
			cipher_data = cipher_data[n:]
			if err != nil {
				fmt.Printf("Send request:")
				fmt.Println(err)
				ShutConn(conn0)
				return
			}
		}
		var flag byte
		for {
			temp := make([]byte, 1)
			n, err := conn1.Read(temp)
			if n == 1 {
				data[1] = temp[0]
				flag = data[1]
				break
			}
			if err != nil {
				fmt.Printf("Send request:")
				fmt.Println(err)
				ShutConn(conn0)
				return
			}
		}
		for len(data) > 0 {
			n, err := conn0.Write(data)
			data = data[n:]
			if err != nil {
				fmt.Printf("Send request:")
				fmt.Println(err)
				ShutConn(conn0)
				return
			}
		}
		if flag != 0 {
			ShutConn(conn0)
			return
		}
		WriteLog(conn1, request_reserve)
		//Send data
		data = data[len(data):]
		cipher_data = cipher_data[len(cipher_data):]
		ch0 := make(chan int)
		ch1 := make(chan int)
		flag0 := 0
		flag1 := 0
		go ReadClient(conn0, &data, ch0)
		go ReadRemote(conn1, &cipher_data, ch1)
		for {
			select {
			case n := <-ch0:
				buf0, n0 := EncryptBlock(data, key)
				data = data[n0:]
				for len(buf0) > 0 {
					n, err := conn1.Write(buf0)
					if err != nil {
						fmt.Printf("Write remote:")
						fmt.Println(err)
						ShutConn(conn0)
						return
					}
					buf0 = buf0[n:]
				}
				if n == 0 {
					flag0 = 1
					if flag1 == 1 {
						ShutConn(conn0)
						ShutConn(conn1)
						return
					}
				}
			case n := <-ch1:
				if len(cipher_data)%128 == 0 {
					buf1, n1 := DecryptBlock(cipher_data, key)
					cipher_data = cipher_data[n1:]
					for len(buf1) > 0 {
						n, err := conn0.Write(buf1)
						if err != nil {
							fmt.Printf("Write client:")
							fmt.Println(err)
							ShutConn(conn1)
							return
						}
						buf1 = buf1[n:]
					}
				}
				if n == 0 {
					flag1 = 1
					if flag0 == 1 {
						ShutConn(conn0)
						ShutConn(conn1)
						return
					}
				}
			}
		}
	}
}

func main() {
	listener, err := net.Listen("tcp", "127.0.0.1:12268")
	if err != nil {
		fmt.Printf("Listen:")
		fmt.Println(err)
		return
	}
	CreateLog()
	for {
		conn0, err0 := listener.Accept()
		if err0 == nil {
			go Forward(conn0)
		} else {
			fmt.Printf("Accept:")
			fmt.Println(err0)
		}
	}
}
